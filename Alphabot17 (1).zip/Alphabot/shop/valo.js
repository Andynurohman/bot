const list_valo = (prefix) => {
return `*ZEEONE OFC さ*
		
PROSES	1-180Mnt Max 1X24 Jam		
OPEN	10.00-19.00		
FORMAT	ID		
			
VALORANT POINT			
		
125VP	18,000.00		
420VP	55,000.00		
700VP	85,000.00		
1.375VP	155,000.00		
2.400VP	250,000.00		
4,000.00VP	395,000.00		
8.150VP	785,000.00		
			
Untuk pay / pembayan silahkan ketik ${prefix}pay
`
	}

exports.list_valo = list_valo
 